import { createContext } from "react";
export  const Data = createContext();