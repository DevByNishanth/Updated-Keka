from django.contrib import admin

from admin_dashboard.models import Leave_admin


admin.site.register(Leave_admin)

