from django.contrib import admin

from employees.models import Employee


admin.site.register(Employee)

