from django.contrib import admin
from .models import Leave

admin.site.register(Leave)
